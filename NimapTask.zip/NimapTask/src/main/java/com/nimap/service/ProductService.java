package com.nimap.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import com.nimap.model.Product;

@Component
public interface ProductService {
	
	public Product saveProduct(Product product);
	
	public Optional<Product> getById(Long pid);
	
	public List<Product> getAllProducts();
	
	public Product updateProduct(Long pid, Product product);
	
	public void deleteProductById(Long pid);
	
	Page<Product> getAllProduct(Pageable pageable);

}
