package com.nimap.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nimap.model.Category;
import com.nimap.repository.CategoryRepository;
import com.nimap.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {
	
	@Autowired
	CategoryRepository categoryRepository;

	@Override
	public Category saveCategory(Category category) {
		
		return categoryRepository.save(category);
	}

	@Override
	public List<Category> getAllCategories() {

		return categoryRepository.findAll();
	}

	@Override
	public Optional<Category> getById(Long cid) {

		return categoryRepository.findById(cid);
	}

	@Override
	public Category updateCategory(Long cid, Category category) {

		return categoryRepository.save(category);
	}

	@Override
	public void deleteById(Long cid) {
		categoryRepository.deleteById(cid);
		
	}

	

	

}
