package com.nimap.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nimap.model.Product;
import com.nimap.repository.ProductRepository;
import com.nimap.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	ProductService productService;
	
	@PostMapping("/save")
	public Product saveProduct(@RequestBody Product product) {
		return productService.saveProduct(product);
	}

	@GetMapping("/findById/{pid}")
	public Optional<Product> getById(@PathVariable Long pid){
		return productService.getById(pid);
	}

	@GetMapping("/findAll")
	public List<Product> getAllProducts(){
		return productService.getAllProducts();
	}
	
	@PutMapping("/update/{pid}")
	public Product updateProduct(@PathVariable Long pid, @RequestBody Product product) {
		return productService.updateProduct(pid, product);
	}

	@DeleteMapping("/delete/{pid}")
	public void deleteProductById(@PathVariable Long pid) {
		productService.deleteProductById(pid);
	}
	
	@GetMapping("/productPage/{pid}")
	public ResponseEntity<Page<Product>> getAllProducts(@RequestParam(defaultValue = "0") int page){
		PageRequest pageable =  PageRequest.of(page, 5);        
		Page<Product> product = productService.getAllProduct(pageable);
		return new ResponseEntity<>(product, HttpStatus.OK);
    }
}
